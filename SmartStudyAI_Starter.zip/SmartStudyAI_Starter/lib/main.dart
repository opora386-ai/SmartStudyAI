import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const SmartStudyApp());

const purple = Color(0xFF6C4CF1);
const ink = Color(0xFF20213A);

class SmartStudyApp extends StatelessWidget {
  const SmartStudyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartStudy AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: purple),
        scaffoldBackgroundColor: const Color(0xFFF7F6FC),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF7F6FC),
          foregroundColor: ink,
          elevation: 0,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int used = 0;
  int bonusUsed = 0;
  bool russian = true;
  bool loading = true;

  int get remaining => (10 - used).clamp(0, 10);

  @override
  void initState() {
    super.initState();
    _loadDailyUsage();
  }

  String _todayKey() {
    final now = DateTime.now();
    return '${now.year}-${now.month}-${now.day}';
  }

  Future<void> _loadDailyUsage() async {
    final prefs = await SharedPreferences.getInstance();
    final savedDay = prefs.getString('usage_day');
    if (savedDay != _todayKey()) {
      await prefs.setString('usage_day', _todayKey());
      await prefs.setInt('used_count', 0);
      await prefs.setInt('bonus_used', 0);
    }
    if (!mounted) return;
    setState(() {
      used = prefs.getInt('used_count') ?? 0;
      bonusUsed = prefs.getInt('bonus_used') ?? 0;
      loading = false;
    });
  }

  Future<void> _saveUsage() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('usage_day', _todayKey());
    await prefs.setInt('used_count', used);
    await prefs.setInt('bonus_used', bonusUsed);
  }

  String t(String ru, String en) => russian ? ru : en;

  Future<void> _openTool(String title, IconData icon) async {
    if (loading) return;
    if (used >= 10) {
      _showLimitDialog();
      return;
    }
    final controller = TextEditingController();
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
          ),
          child: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(4)))),
                const SizedBox(height: 18),
                Row(children: [CircleAvatar(backgroundColor: purple.withOpacity(.12), child: Icon(icon, color: purple)), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))]),
                const SizedBox(height: 12),
                Text(t('Напиши вопрос или вставь текст. Это демонстрационная версия: ИИ пока не подключён.', 'Type a question or paste text. This is a demo: AI is not connected yet.')),
                const SizedBox(height: 12),
                TextField(controller: controller, maxLines: 4, decoration: InputDecoration(hintText: t('Например: объясни дроби простыми словами…', 'For example: explain fractions simply…'), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
                const SizedBox(height: 14),
                SizedBox(width: double.infinity, child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.symmetric(vertical: 15)),
                  onPressed: () {
                    if (controller.text.trim().isEmpty) return;
                    Navigator.pop(ctx, controller.text.trim());
                  },
                  child: Text(t('Отправить задание', 'Submit task')),
                )),
              ],
            ),
          ),
        ),
      ),
    );
    if (result == null) return;
    setState(() => used = (used + 1).clamp(0, 10));
    await _saveUsage();
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t('Задание принято', 'Task received')),
        content: Text(t(
          'Это стартовая версия интерфейса. Чтобы приложение отвечало на вопросы, нужно подключить AI API и защищённый сервер. Твой запрос: "$result"',
          'This is the starter UI. To generate answers, connect an AI API through a secure backend. Your prompt: "$result"',
        )),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  void _showLimitDialog() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t('Лимит на сегодня исчерпан', 'Daily limit reached')),
        content: Text(t(
          'Ты использовал 10 бесплатных заданий. Можно вернуться завтра или посмотреть вознаграждаемую рекламу, чтобы получить ещё 2 задания. В этой демоверсии реклама пока не подключена.',
          'You used your 10 free tasks. Come back tomorrow or watch a rewarded ad for 2 more tasks. Ads are not connected in this demo.',
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(t('Завтра', 'Tomorrow'))),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: purple),
            onPressed: () {
              Navigator.pop(ctx);
              _showAdNotice();
            },
            child: Text(t('Получить +2', 'Get +2')),
          ),
        ],
      ),
    );
  }

  void _showAdNotice() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t('Реклама ещё не подключена', 'Ads not connected yet')),
        content: Text(t(
          'Позже подключим Google AdMob. Бонусы нельзя выдавать только по нажатию кнопки: приложение должно подтвердить просмотр рекламы.',
          'Google AdMob will be connected later. Bonus tasks must only be granted after the ad network confirms a completed ad view.',
        )),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  Widget _toolCard(String title, String subtitle, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFEDEAF8))),
        child: Row(children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(color: purple.withOpacity(.10), borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: purple, size: 25)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: ink, fontSize: 16)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
          ])),
          const Icon(Icons.chevron_right, color: Colors.black38),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.auto_awesome, color: purple),
          SizedBox(width: 8),
          Text('SmartStudy AI', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          TextButton(
            onPressed: () => setState(() => russian = !russian),
            child: Text(russian ? 'RU | EN' : 'EN | RU', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF7658F5), Color(0xFF5135D7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                      borderRadius: BorderRadius.circular(26),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(t('Учись умнее. Работай проще.', 'Study smarter. Work easier.'), style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Text(t('Твои идеи — наш следующий шаг.', 'Your ideas, one step further.'), style: const TextStyle(color: Colors.white70, fontSize: 14)),
                      const SizedBox(height: 20),
                      Row(children: [
                        const Icon(Icons.bolt, color: Colors.white),
                        const SizedBox(width: 8),
                        Expanded(child: Text(t('Бесплатные задания сегодня', 'Free tasks today'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
                        Text('$remaining/10', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                      ]),
                      const SizedBox(height: 10),
                      ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: remaining / 10, minHeight: 7, backgroundColor: Colors.white24, color: Colors.white)),
                    ]),
                  ),
                  const SizedBox(height: 24),
                  Text(t('Что будем делать?', 'What do you need?'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: ink)),
                  const SizedBox(height: 12),
                  _toolCard(t('Помощь с учёбой', 'Study help'), t('Темы, задания и подготовка к экзаменам', 'Topics, homework and exam prep'), Icons.school_outlined, () => _openTool(t('Помощь с учёбой', 'Study help'), Icons.school_outlined)),
                  const SizedBox(height: 10),
                  _toolCard(t('Помощь с работой', 'Work assistant'), t('Письма, резюме и собеседования', 'Emails, CVs and interviews'), Icons.work_outline, () => _openTool(t('Помощь с работой', 'Work assistant'), Icons.work_outline)),
                  const SizedBox(height: 10),
                  _toolCard(t('Переводчик', 'Translator'), t('Перевод и улучшение текста', 'Translate and improve text'), Icons.translate, () => _openTool(t('Переводчик', 'Translator'), Icons.translate)),
                  const SizedBox(height: 10),
                  _toolCard(t('Объяснить тему', 'Explain a topic'), t('Сложное — простыми словами', 'Complex ideas made simple'), Icons.lightbulb_outline, () => _openTool(t('Объяснить тему', 'Explain a topic'), Icons.lightbulb_outline)),
                  const SizedBox(height: 18),
                  Center(child: Text(t('Бесплатно • Русский и английский', 'Free • Russian and English'), style: const TextStyle(color: Colors.black45, fontSize: 12))),
                ],
              ),
            ),
    );
  }
}
